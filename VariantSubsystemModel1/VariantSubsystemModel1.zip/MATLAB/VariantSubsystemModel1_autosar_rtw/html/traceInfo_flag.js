function TraceInfoFlag() {
    this.traceFlag = new Array();
    this.traceFlag["VariantSubsystemModel1.c:29c41"]=1;
    this.traceFlag["VariantSubsystemModel1.c:29c46"]=1;
    this.traceFlag["VariantSubsystemModel1.c:29c72"]=1;
    this.traceFlag["VariantSubsystemModel1.c:30c29"]=1;
    this.traceFlag["VariantSubsystemModel1.c:33c26"]=1;
    this.traceFlag["VariantSubsystemModel1.c:41c58"]=1;
}
top.TraceInfoFlag.instance = new TraceInfoFlag();
function TraceInfoLineFlag() {
    this.lineTraceFlag = new Array();
    this.lineTraceFlag["VariantSubsystemModel1.c:29"]=1;
    this.lineTraceFlag["VariantSubsystemModel1.c:30"]=1;
    this.lineTraceFlag["VariantSubsystemModel1.c:31"]=1;
    this.lineTraceFlag["VariantSubsystemModel1.c:33"]=1;
    this.lineTraceFlag["VariantSubsystemModel1.c:41"]=1;
}
top.TraceInfoLineFlag.instance = new TraceInfoLineFlag();
