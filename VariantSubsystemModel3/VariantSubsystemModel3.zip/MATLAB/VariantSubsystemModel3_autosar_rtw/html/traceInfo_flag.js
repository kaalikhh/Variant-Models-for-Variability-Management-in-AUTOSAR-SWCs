function TraceInfoFlag() {
    this.traceFlag = new Array();
    this.traceFlag["VariantSubsystemModel3.c:34c36"]=1;
    this.traceFlag["VariantSubsystemModel3.c:34c41"]=1;
    this.traceFlag["VariantSubsystemModel3.c:34c67"]=1;
    this.traceFlag["VariantSubsystemModel3.c:35c29"]=1;
    this.traceFlag["VariantSubsystemModel3.c:38c26"]=1;
    this.traceFlag["VariantSubsystemModel3.c:46c38"]=1;
    this.traceFlag["VariantSubsystemModel3.c:51c39"]=1;
    this.traceFlag["VariantSubsystemModel3.c:51c46"]=1;
}
top.TraceInfoFlag.instance = new TraceInfoFlag();
function TraceInfoLineFlag() {
    this.lineTraceFlag = new Array();
    this.lineTraceFlag["VariantSubsystemModel3.c:31"]=1;
    this.lineTraceFlag["VariantSubsystemModel3.c:34"]=1;
    this.lineTraceFlag["VariantSubsystemModel3.c:35"]=1;
    this.lineTraceFlag["VariantSubsystemModel3.c:36"]=1;
    this.lineTraceFlag["VariantSubsystemModel3.c:38"]=1;
    this.lineTraceFlag["VariantSubsystemModel3.c:46"]=1;
    this.lineTraceFlag["VariantSubsystemModel3.c:51"]=1;
}
top.TraceInfoLineFlag.instance = new TraceInfoLineFlag();
